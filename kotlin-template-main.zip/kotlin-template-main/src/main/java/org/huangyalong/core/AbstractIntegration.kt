package org.huangyalong.core

abstract class AbstractIntegration
