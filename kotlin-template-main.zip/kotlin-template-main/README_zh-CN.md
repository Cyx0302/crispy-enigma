[English](./README.md) | 简体中文

# kotlin-template

[![](https://img.shields.io/badge/maven-3.8.5-02303a.svg?style=flat-square)](https://maven.apache.org/download.cgi)
[![](https://img.shields.io/badge/java-1.8.0-fb9d40.svg?style=flat-square)](https://www.oracle.com/technetwork/java/javase/downloads/index.html)
[![](https://img.shields.io/dub/l/vibe-d.svg?style=flat-square)](https://tldrlegal.com/license/mit-license)

这是一个构建 Kotlin 项目的模板库
